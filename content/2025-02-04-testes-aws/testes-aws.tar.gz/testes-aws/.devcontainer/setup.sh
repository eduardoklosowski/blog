#!/bin/bash

set -eux

# Completion
mkdir -p ~/.local/share/bash-completion/completions
echo 'eval "$(pip completion --bash)"' > ~/.local/share/bash-completion/completions/pip

# Init project
make init
