class Bot():
    def __init__(self):
        self.__commandos = {}

    def comando(self, cmd):
        def anotacao(f):
            self.__commandos[cmd] = f
            return f
        return anotacao
