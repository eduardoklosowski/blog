from random import randint

from lib import Bot


bot = Bot()


@bot.comando('!amizade')
def amizade(msg):
    amizade = randint(0, 100)
    return f'Sua amizade com {msg} é de {amizade}%.'
