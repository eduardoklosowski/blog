from random import randint

from lib import Bot


def newcomando(self, cmd):
    def anotacao(f):
        def func(msg):
            if msg == 'vitthin':
                amizade = randint(0, 10)
                return f'Sua amizade com {msg} é de {amizade}%.'
            if msg == 'morgiovanelli':
                amizade = randint(90, 100)
                return f'Sua amizade com {msg} é de {amizade}%.'
            return f(msg)
        return func
    return anotacao

Bot.comando = newcomando
